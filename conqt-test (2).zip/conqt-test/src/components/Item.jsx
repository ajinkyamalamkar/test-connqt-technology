import React, { useState } from "react";

const Item = ({ item, setItem }) => {
  const handleChange = (e) => {
    setItem({
      ...item,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "center" }}>
        <h1>Item Details</h1>
      </div>
      <div className="items-details">
        <div className="form">
          <div className="item-sub">
            <div>
              <label className="label">item Name</label>
              <div>
                <input
                  type="text"
                  placeholder="Enter item name"
                  className="input"
                  max={225}
                  name="itemName"
                  value={item.itemName}
                  onChange={handleChange}
                ></input>
              </div>
              <span className="msg">Max 50 Characters</span>
            </div>
            <div>
              <label className="label">Quantity</label>
              <div>
                <input
                  className="input"
                  type="number"
                  placeholder="Enter quantity"
                  max={10}
                  name="quantity"
                  value={item.quantity}
                  onChange={handleChange}
                ></input>
              </div>
              <span className="msg">Numeric value</span>
            </div>
          </div>
          <div className="item-sub">
            <div>
              <label className="label">Unit Price</label>
              <div>
                <input
                  className="input"
                  type="number"
                  placeholder="Enter Unit Price"
                  name="unitPrice"
                  value={item.unitPrice}
                  onChange={handleChange}
                ></input>
              </div>
              <span className="msg">Numeric value (USD)</span>
            </div>

            <div>
              <label className="label">currency</label>
              <div>
                <input
                  className="input"
                  type="text"
                  placeholder="Enter currency"
                  name="currency"
                  value={item.currency}
                  onChange={handleChange}
                ></input>
              </div>
              <span className="msg">Numeric value (USD)</span>
            </div>
          </div>
          <div className="item-sub">
            <div>
              <label className="label">Date of Submission</label>
              <div style={{ width: "100%" }}>
                <input
                  className="input-date"
                  type="date"
                  placeholder="Enter Unit Price"
                  name="submissionDate"
                  value={item.submissionDate}
                  onChange={handleChange}
                ></input>
              </div>
              <span className="msg">Format: MM/DD/YYYY</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Item;
