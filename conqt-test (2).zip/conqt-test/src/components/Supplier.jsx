import axios from "axios";
import React, { useEffect, useState } from "react";

const Supplier = ({ supplier, setSupplier }) => {
  const [country, setCountry] = useState();
  const [state, setState] = useState();
  const [city, setCity] = useState();

  const handleChange = (e) => {
    setSupplier({
      ...supplier,
      [e.target.name]: e.target.value,
    });
  };

  const fetchAllCountry = async () => {
    try {
      const res = await axios.get(
        "https://apis-technical-test.conqt.com/Api/countrystatecity/Get-All-CountryList"
      );
      console.log(res, "llll");
      setCountry(res.data.data.countyList);
    } catch (error) {
      console.log(error);
    }
  };

  const fetchAllState = async () => {
    try {
      const res = await axios.get(
        `https://apis-technical-test.conqt.com/Api/countrystatecity/Get-All-SateList-By-Country?countryId=${supplier?.countryId}`
      );
      console.log(res, "eeee");
      setState(res.data.data.stateList);
    } catch (error) {
      console.log(error);
    }
  };

  const fetchAllCity = async () => {
    try {
      const res = await axios.get(
        `https://apis-technical-test.conqt.com/Api/countrystatecity/Get-All-CityList-By-Country-State?countryId=${countryId}&stateId=${stateId}`
      );
      console.log(res, "llll");
      setCity(res.data.data.countyList);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchAllCountry();
    fetchAllState();
    fetchAllCity();
  }, []);

  console.log(country, "coun", supplier);

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "center" }}>
        <h1>Supplier Details</h1>
      </div>
      <div className="items-details">
        <div className="form">
          <div className="item-sub">
            <div>
              <label className="label">Supplier name</label>
              <div>
                <input
                  className="input"
                  type="text"
                  placeholder="Enter supplier name"
                  max={225}
                  name="supplierName"
                  value={supplier.supplierName}
                  onChange={handleChange}
                ></input>
              </div>
              <span className="msg">Max 50 Characters</span>
            </div>
            <div>
              <label className="label">Company Name</label>
              <div>
                <input
                  className="input"
                  type="text"
                  placeholder="Enter Company Name"
                  max={225}
                  name="companyName"
                  value={supplier.companyName}
                  onChange={handleChange}
                ></input>
              </div>
              <span className="msg">Max 50 Characters</span>
            </div>
          </div>
          <div className="item-sub">
            <div>
              <label className="label">Country</label>
              <div>
                <select
                  name="countryId"
                  value={supplier.countryId}
                  onChange={handleChange}
                >
                  <option>Select</option>
                  {country &&
                    country?.map((item) => (
                      <option key={item.countryId} value={item.countryId}>
                        {item.name}
                      </option>
                    ))}
                </select>
              </div>
              <span className="msg">Select country from the list</span>
            </div>
            <div>
              <label className="label">State</label>
              <div>
                <select
                  name="stateId"
                  value={supplier.stateId}
                  onChange={handleChange}
                >
                  <option>Select</option>
                  {state &&
                    state?.map((item) => (
                      <option key={item.stateId} value={item.stateId}>
                        {item.name}
                      </option>
                    ))}
                </select>
              </div>
              <span className="msg">Select State from the list</span>
            </div>
          </div>
          <div className="item-sub">
            <div>
              <label className="label">City</label>
              <div>
                <select
                  name="cityId"
                  value={supplier.cityId}
                  onChange={handleChange}
                >
                  <option>Select</option>
                  {state &&
                    state?.map((item) => (
                      <option key={item.cityId} value={item.cityId}>
                        {item.name}
                      </option>
                    ))}
                </select>
              </div>
              <span className="msg">Max 50 Characters</span>
            </div>
            <div>
              <div>
                <label className="label">Email Address</label>
                <div>
                  <input
                    type="email"
                    placeholder="Enter Email Address"
                    className="input"
                    name="email"
                    value={supplier.email}
                    onChange={handleChange}
                  ></input>
                </div>
                <span className="msg">Valid email format</span>
              </div>
            </div>
          </div>
          <div className="item-sub">
            <div>
              <label className="label">Phone Code</label>
              <div>
                <input
                  className="input"
                  type="text"
                  placeholder="Enter Phone Code"
                  name="phoneCode"
                  value={supplier.phoneCode}
                  onChange={handleChange}
                ></input>
              </div>
              <span className="msg">valid phone number</span>
            </div>
            <div>
              <label className="label">Phone Number</label>
              <div>
                <input
                  className="input"
                  type="text"
                  placeholder="Enter Phone Number"
                  name="phoneNumber"
                  value={supplier.phoneNumber}
                  onChange={handleChange}
                ></input>
              </div>
              <span className="msg">valid phone number</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Supplier;
