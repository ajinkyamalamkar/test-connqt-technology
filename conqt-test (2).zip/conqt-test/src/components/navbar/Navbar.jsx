import React from "react";
import "./Navbar.css";
import { Link, NavLink } from "react-router-dom";

const Navbar = () => {
  return (
    <div
      style={{
        backgroundColor: "#007AFF",
        padding: "20px",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            alignContent: "center",
          }}
        >
          <img src="/logo.png" alt="logo" style={{ marginTop: "5px" }} />
          <span className="heading">Inventory Management System</span>
        </div>
        <div>
          <NavLink to={"/home"} className={"heading-link"}>Home</NavLink>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
