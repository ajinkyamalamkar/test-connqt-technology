import React, { useState } from "react";
import Navbar from "../navbar/Navbar";
import "./home.css";
import Item from "../Item";
import Supplier from "../Supplier";
import SavedData from "../SavedData";
import axios from "axios";

const Home = () => {
  const [itemCheck, setItemCheck] = useState("item");

  const [item, setItem] = useState({
    itemName: "",
    quantity: 0,
    unitPrice: 0,
    currency: "",
    submissionDate: "",
  });

  const [supplier, setSupplier] = useState({
    supplierName: "",
    companyName: "",
    email: "",
    phoneCode: "",
    phoneNumber: "",
    countryId: "",
    stateId: "",
    cityId: "",
  });

  const handleClick = (data) => {
    console.log(data);
    setItemCheck(data);
  };

  console.log(item);
  console.log(supplier);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      console.log("hello");
      const data = { itemDetails: item, supplier: supplier };
      console.log(data);

      const d = await axios.post(
        "https://apis-technical-test.conqt.com/Api/Item-Supplier/Save-Items-Suppliers",
        data
      );
      console.log(d, "ddd");
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <Navbar />
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          marginTop: "20px",
        }}
      >
        <div style={{ marginRight: "5px" }}>
          <input
            type="checkbox"
            className="check"
            checked={itemCheck === "item"}
            onClick={() => handleClick("item")}
          />
          <span className="check-items">Item</span>
        </div>
        <div style={{ marginLeft: "5px" }}>
          <input
            type="checkbox"
            className="check"
            checked={itemCheck === "supplier"}
            onClick={() => handleClick("supplier")}
          />
          <span className="check-items">Supplier</span>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        {/* item details */}
        {itemCheck === "item" && <Item item={item} setItem={setItem} />}

        {/* Supplier deatils */}
        {itemCheck === "supplier" && (
          <Supplier supplier={supplier} setSupplier={setSupplier} />
        )}

        <div>
          <div style={{ display: "flex", justifyContent: "center" }}>
            <h1>Submitted Data</h1>
          </div>
          <div>
            <p className="p-data">
              The data submitted by users will be displayed below
            </p>
          </div>
          <div style={{ display: "flex", justifyContent: "center" }}>
            <button className="submit-button" type="submit">
              Save Changes
            </button>
          </div>
        </div>
      </form>
      <SavedData />
    </>
  );
};

export default Home;
