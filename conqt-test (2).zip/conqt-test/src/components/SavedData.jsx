import axios from "axios";
import React, { useEffect, useState } from "react";

const SavedData = () => {
  const [data, setData] = useState([]);

  const fetchAllData = async () => {
    try {
      const res = await axios.get(
        "https://apis-technical-test.conqt.com/Api/Item-Supplier/Get-All-Items"
      );
      setData(res.data.data.items);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <div>
        {/* table */}

        <div>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <h1>Uploaded Data</h1>
            <div>
              <button>Clear All</button>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th>
                  <input type="checkbox" />
                  Supplier
                </th>
                <th>Item Name</th>
                <th>Quantity</th>
                <th>City</th>
                <th>Country</th>
                <th>Email</th>
                <th>Phone Number</th>
              </tr>
            </thead>
            <tbody>
              {data &&
                data?.map((item, index) => (
                  <tr key={index}>
                    <td>
                      {" "}
                      <input type="checkbox" /> {item.Supplier?.supplierName}
                    </td>
                    <td>{item.itemName}</td>
                    <td>{item.quantity}</td>
                    <td>{item.Supplier?.cityName}</td>
                    <td>{item.Supplier.countryName}</td>
                    <td>{item.Supplier.email}</td>
                    <td>{item.Supplier.phoneNumber}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SavedData;
